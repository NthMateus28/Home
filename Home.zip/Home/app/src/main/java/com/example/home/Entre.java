package com.example.home;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Entre extends AppCompatActivity {
    private EditText Username;
    Button btnEntrar2, btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entre);

        Username = findViewById(R.id.Username);
        btnEntrar2 = findViewById(R.id.btnEntrar2);
        btnVoltar = findViewById(R.id.btnVoltar);

        btnEntrar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirEscolha();
            }
        });
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMain();
            }
        });
    }
    public void abrirEscolha()
    {
        Intent janela = new Intent(this, Escolha.class);
        startActivity(janela);
    }
    public void abrirMain()
    {
        Intent janelam = new Intent(this, MainActivity.class);
        startActivity(janelam);
    }
}