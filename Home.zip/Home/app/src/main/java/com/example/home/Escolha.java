package com.example.home;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Escolha extends AppCompatActivity {
    private Button btnContinuar, btnVoltar2;
    private TextView resposta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_escolha);

        resposta = findViewById(R.id.resposta);
        btnContinuar = findViewById(R.id.btnContinuar);
        btnVoltar2 = findViewById(R.id. btnVolta2);

        String recebe = getIntent().getStringExtra("Username");
        resposta.setText(recebe);

        btnContinuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirPersonagem();
            }
        });
        btnVoltar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirEntre();
            }
        });
    }
    public void abrirPersonagem()
    {
        Intent janela = new Intent(this, Personagem.class);
        startActivity(janela);
    }
    public void abrirEntre()
    {
        Intent janelae = new Intent(this, Entre.class);
        startActivity(janelae);
    }
}