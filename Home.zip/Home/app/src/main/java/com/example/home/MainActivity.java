package com.example.home;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btnEntrar, btnSair;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnEntrar = findViewById(R.id.btnEntrar);
        btnSair = findViewById(R.id.btnSair);

        btnEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirEntre();
            }
        });
        btnSair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Volte Sempre!", Toast.LENGTH_SHORT).show();
                abriSair();
            }
        });
    }
    public void abrirEntre()
    {
        Intent janela = new Intent(this, Entre.class);
        startActivity(janela);
    }
    private void abriSair()
    {
        this.finishAffinity();
    }
    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Para Sair, Clique no botão Sair!", Toast.LENGTH_LONG).show();
    }
}